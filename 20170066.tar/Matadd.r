m1<- matrix(c(1:10,100), nrow=10, ncol=10, byrow=TRUE)
m2<- matrix(c(1:10,100), nrow=10, ncol=10, byrow=TRUE)

sum <-m1 + m2

cat("addition of matrix")
print(sum)

