m <-matrix(c(floor(runif(2500, min=0, max=4))), nrow=10, ncol=5, byrow=TRUE)
print(m)
